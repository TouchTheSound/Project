<?php ?>
	<table>
		<tr>
			<td><?php echo("Mode");?>
			</td>
			<td><?php echo("Documentation");?>
			</td>
			<td><?php  echo("Divers");?>
			</td>
		</tr>
	</table>
<?php ?>
