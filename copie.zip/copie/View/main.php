<?php

	$len=count($ListPatches);
	$i=0;
	for($i=0;$i<$len;$i++){
		if($ListPatches[$i]!="." && $ListPatches[$i]!=".."){
			?>
			<form action="index.php" methode="post">
				<input type="hidden" name="Patches"  value=<?php echo($ListPatches[$i]) ?>>
				<p><input type="submit" value=<?php echo($ListPatches[$i]) ?>></p>

			</form>
				<?php //echo("$ListPatches[$i]"); 
				?>
			<?php
		}
	}
	/*for($i=1; i<$len; $i++){
		echo $ListPatches[$i];
	}*/
	/*foreach($ListPatches as $File){
		i++;
		echo($File);
		echo($i);
	}*/
	//print_r($ListPatches);
?>
