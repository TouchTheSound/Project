import os
os.system('Fichier/teste_son_rasp.pd')
