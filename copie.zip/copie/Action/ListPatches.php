<?php

	$ListPatches=scandir("Fichier");
?>
