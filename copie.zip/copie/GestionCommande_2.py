import os
import time
from threading import Thread
import subprocess
import time
import commands




print("Start")		
while True :
	try :
		with open('StartPureData/commande.txt') :
			
			my_file=open('StartPureData/commande.txt')
			status, output = commands.getstatusoutput ("pidof pd")
			status, output = commands.getstatusoutput ("kill "+str(output))
			
			output =os.system(my_file.read()+" &")
			
			my_file.close()
			os.remove('StartPureData/commande.txt')

	except IOError :
		pass
