<?php
	include "Action/ListPatches.php";

	if($_GET){
		//echo("On a un post");
		//print_r($_GET);
		if(isset($_GET["Patches"])){
			$commande="pd -nogui Fichier/" .$_GET["Patches"];
			echo($commande);
			//$last_line = system($commande, $retval);
			//exec("cp index.php index_copie.php");
			//echo(exec($commande));
			exec($commande);
			//shell_exec("pd Fichier/".$_GET["Patches"]);
		}
		//echo($_GET["Patches"])
	}

	include "View/header.php";
	include "View/main.php";
 ?>
