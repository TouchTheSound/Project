<?php
	include "Action/ListPatches.php";?>

	<link rel='stylesheet' href="Style/button.css" type="text/CSS">
	<?php
	if($_GET){
		//echo("On a un post");
		//print_r($_GET);
		if(isset($_GET["Patches"])){
			$commande="pd -nogui Fichier/" .$_GET["Patches"];
			//echo($commande);
			exec('python start_patch.py');
			//$last_line = system($commande, $retval);
			//exec("cp index.php index_copie.php");
			//echo(exec($commande));
			$File=fopen("StartPureData/commande.txt","a+");
			fputs($File,$commande);
			fclose($File);
			//shell_exec("pd Fichier/".$_GET["Patches"]);
		}
		//echo($_GET["Patches"])
	}

	include "View/header.php";
	include "View/main.php";
 ?>
